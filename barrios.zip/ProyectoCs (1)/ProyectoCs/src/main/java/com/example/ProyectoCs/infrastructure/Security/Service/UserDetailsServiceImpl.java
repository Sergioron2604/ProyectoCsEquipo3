package com.example.ProyectoCs.infrastructure.Security.Service;



import com.example.ProyectoCs.domain.model.Estudiante;
import com.example.ProyectoCs.domain.model.Propietario;
import com.example.ProyectoCs.domain.repository.EstudianteRepository;
import com.example.ProyectoCs.domain.repository.PropietarioRepository;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    private final EstudianteRepository estudianteRepository;
    private final PropietarioRepository propietarioRepository;

    public UserDetailsServiceImpl(EstudianteRepository estudianteRepository, PropietarioRepository propietarioRepository) {
        this.estudianteRepository = estudianteRepository;
        this.propietarioRepository = propietarioRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Estudiante estudiante = estudianteRepository.findBy(username);
        if (estudiante != null) {
            return new UserDetailsImpl(estudiante);
        }

        Propietario propietario = propietarioRepository.findByUsuario(username);
        if (propietario != null) {
            return new UserDetailsImpl(propietario);
        }

        throw new UsernameNotFoundException("Usuario no encontrado: " + username);
    }
}

