package com.example.ProyectoCs.application.dto;

import lombok.Data;

@Data
public class TipoAlojamientoDTO {
    private int tipoAlojamientoID;
    private String nombreTipoAlojamiento;
}
