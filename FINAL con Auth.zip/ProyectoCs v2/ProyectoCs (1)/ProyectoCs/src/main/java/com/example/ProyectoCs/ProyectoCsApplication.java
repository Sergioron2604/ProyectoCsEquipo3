package com.example.ProyectoCs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoCsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoCsApplication.class, args);
	}

}
