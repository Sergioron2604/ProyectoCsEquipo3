package com.example.ProyectoCs.domain.repository;

import com.example.ProyectoCs.domain.model.ComportamientoBusqueda;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ComportamientoBusquedaRepository extends JpaRepository<ComportamientoBusqueda, Long> {
}
