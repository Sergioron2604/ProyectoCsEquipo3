package com.example.ProyectoCs;

import org.junit.jupiter.api.Test;

class ProyectoCsApplicationTests {

	@Test
	void contextLoads() {
	}

}
