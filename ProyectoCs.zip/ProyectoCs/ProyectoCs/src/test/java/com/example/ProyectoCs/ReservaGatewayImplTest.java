package com.example.ProyectoCs;

import com.example.ProyectoCs.application.dto.ReservaDTO;
import com.example.ProyectoCs.application.service.NotificationService;
import com.example.ProyectoCs.domain.model.Alojamiento;
import com.example.ProyectoCs.domain.model.EstadoHabitacion;
import com.example.ProyectoCs.domain.model.EstadoReserva;
import com.example.ProyectoCs.domain.model.Reserva;
import com.example.ProyectoCs.infrastructure.gateway.ReservaGatewayImpl;
import com.example.ProyectoCs.domain.repository.AlojamientoRepository;
import com.example.ProyectoCs.domain.repository.EstadoReservaRepository;
import com.example.ProyectoCs.domain.repository.EstudianteRepository;
import com.example.ProyectoCs.domain.repository.ReservaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import javax.mail.MessagingException;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ReservaGatewayImplTest {

    @Mock
    private ReservaRepository reservaRepository;

    @Mock
    private AlojamientoRepository alojamientoRepository;

    @Mock
    private EstadoReservaRepository estadoReservaRepository;

    @Mock
    private NotificationService notificationService;

    @Mock
    private EstudianteRepository estudianteRepository;

    @InjectMocks
    private ReservaGatewayImpl reservaGateway;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void saveReserva_ReservaSavedSuccessfully() throws MessagingException, jakarta.mail.MessagingException {
        // Setup
        ReservaDTO reservaDTO = new ReservaDTO();
        reservaDTO.setIdAlojamiento(1);
        reservaDTO.setEmailEstudiante("student@example.com");
        reservaDTO.setFechaInicio(new Date());
        reservaDTO.setFechaFin(new Date());
        Alojamiento alojamiento = new Alojamiento();
        alojamiento.setIdAlojamiento(1);
        when(alojamientoRepository.findById((int) Math.toIntExact(1L))).thenReturn(Optional.of(alojamiento));
        when(estadoReservaRepository.findById(1L)).thenReturn(Optional.of(new EstadoReserva()));
        doNothing().when(notificationService).sendNewReserve(reservaDTO);

        // Verify
        assertDoesNotThrow(() -> reservaGateway.saveReserva(reservaDTO));
    }

    @Test
    void saveReserva_ThrowsExceptionWhenAlojamientoNotFound() {
        // Setup
        ReservaDTO reservaDTO = new ReservaDTO();
        reservaDTO.setIdAlojamiento(1);
        when(alojamientoRepository.findById(1)).thenReturn(Optional.empty());

        // Verify
        assertThrows(IllegalArgumentException.class, () -> reservaGateway.saveReserva(reservaDTO));
    }

    @Test
    void saveReserva_ThrowsExceptionWhenAlojamientoNotAvailable() throws Exception {
        // Setup
        ReservaDTO reservaDTO = new ReservaDTO();
        reservaDTO.setIdAlojamiento(1);
        Alojamiento alojamiento = new Alojamiento();
        EstadoHabitacion estadoHabitacion = new EstadoHabitacion();
        estadoHabitacion.setIdEstadoHabitacion(2); // Estado ocupado
        alojamiento.setEstadoHabitacion(estadoHabitacion);
        when(alojamientoRepository.findById(1)).thenReturn(Optional.of(alojamiento));

        // Verify
        assertThrows(IllegalStateException.class, () -> reservaGateway.saveReserva(reservaDTO));
    }

    @Test
    void saveReserva_ThrowsExceptionWhenConflictWithExistingReserva() {
        // Setup
        ReservaDTO reservaDTO = new ReservaDTO();
        reservaDTO.setIdAlojamiento((int) 1);
        when(alojamientoRepository.findById(1)).thenReturn(Optional.of(new Alojamiento()));
        when(reservaRepository.findAll()).thenReturn(new ArrayList<>()); // No hay reservas existentes

        // Verify
        assertDoesNotThrow(() -> reservaGateway.saveReserva(reservaDTO));

        // Agregar una reserva existente que entra en conflicto con la nueva reserva
        Reserva reservaExistente = new Reserva();
        reservaExistente.setAlojamiento(new Alojamiento());
        reservaExistente.setFechaInicio(new Date());
        reservaExistente.setFechaFin(new Date());
        List<Reserva> reservasExistentes = new ArrayList<>();
        reservasExistentes.add(reservaExistente);
        when(reservaRepository.findAll()).thenReturn(reservasExistentes);

        // Verify
        assertThrows(IllegalStateException.class, () -> reservaGateway.saveReserva(reservaDTO));
    }


    @Test
    void cancelarReserva_CancelsReservaSuccessfully() {
        Reserva reserva = createReserva(); // Crear una instancia de Reserva válida
        reserva.getEstadoReserva().setIdEstadoReserva(1); // Asegurarse de que el estado de la reserva es activo
        when(reservaRepository.findById(1L)).thenReturn(Optional.of(reserva));

        String result = reservaGateway.cancelarReserva(1);

        verify(reservaRepository, times(1)).save(reserva);
        assertEquals("La reserva ha sido cancelada exitosamente.", result);
    }

    // Método para crear una instancia de Reserva válida para la prueba
    private Reserva createReserva() {
        Reserva reserva = new Reserva();
        reserva.setEstadoReserva(new EstadoReserva()); // Estado de reserva por defecto
        return reserva;
    }

    @Test
    void cancelarReserva_ReservaNotFound() {
        when(reservaRepository.findById(1L)).thenReturn(Optional.empty());

        String result = reservaGateway.cancelarReserva(1);

        verify(reservaRepository, never()).save(any());
        assertEquals("Reserva no encontrada.", result);
    }

    private ReservaDTO createReservaDTO() {
        ReservaDTO reservaDTO = new ReservaDTO();
        reservaDTO.setIdAlojamiento(1);
        reservaDTO.setEmailEstudiante("student@example.com");
        reservaDTO.setFechaInicio(new Date());
        reservaDTO.setFechaFin(new Date());
        return reservaDTO;
    }

    private Alojamiento createAlojamiento() {
        Alojamiento alojamiento = new Alojamiento();
        EstadoHabitacion estadoHabitacion = new EstadoHabitacion();
        estadoHabitacion.setIdEstadoHabitacion(1); // Estado disponible
        alojamiento.setEstadoHabitacion(estadoHabitacion);
        return alojamiento;
    }
}
