package com.example.ProyectoCs.infrastructure.gateway;

import com.example.ProyectoCs.application.dto.EstadoPropietarioDTO;

public interface EstadoPropietarioGateway {
    void saveEstadoPropietario(EstadoPropietarioDTO estadoPropietarioDTO);
}
