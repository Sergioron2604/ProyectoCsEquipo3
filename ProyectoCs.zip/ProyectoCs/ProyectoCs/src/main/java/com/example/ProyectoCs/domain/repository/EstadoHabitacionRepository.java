package com.example.ProyectoCs.domain.repository;

import com.example.ProyectoCs.domain.model.EstadoHabitacion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EstadoHabitacionRepository extends JpaRepository<EstadoHabitacion, Long> {
}
