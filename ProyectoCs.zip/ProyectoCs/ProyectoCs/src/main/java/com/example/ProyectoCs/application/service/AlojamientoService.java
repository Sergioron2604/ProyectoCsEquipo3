package com.example.ProyectoCs.application.service;

import com.example.ProyectoCs.application.dto.AlojamientoDTO;
import com.example.ProyectoCs.application.dto.EstudianteDTO;
import com.example.ProyectoCs.application.dto.PreferenciaEstudianteDTO;
import com.example.ProyectoCs.domain.model.Alojamiento;
import com.example.ProyectoCs.domain.model.Estudiante;
import com.example.ProyectoCs.domain.repository.AlojamientoRepository;
import com.example.ProyectoCs.domain.repository.EstudianteRepository;
import com.example.ProyectoCs.infrastructure.gateway.AlojamientoGateway;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jakarta.mail.MessagingException;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class AlojamientoService {

    private final AlojamientoGateway alojamientoGateway;
    private final AlojamientoRepository alojamientoRepository;


    @Autowired
    public AlojamientoService(AlojamientoGateway alojamientoGateway, AlojamientoRepository alojamientoRepository,
                              EstudianteRepository estudianteRepository, NotificationService notificationService,
                              EstudianteService estudianteService) {
        this.alojamientoGateway = alojamientoGateway;
        this.alojamientoRepository = alojamientoRepository;
    }

    public List<AlojamientoDTO> filtrarAlojamientos(double precioMin, double precioMax, String ciudad,
                                                    boolean tieneLavanderia, boolean tieneRoomie,
                                                    boolean tieneParqueaderoBicicleta) {
        return alojamientoGateway.filtrarAlojamientos(precioMin, precioMax, ciudad, tieneLavanderia, tieneRoomie,
                tieneParqueaderoBicicleta);
    }

    @SneakyThrows
    public void crearNuevaHabitacion(AlojamientoDTO alojamientoDTO) {
        Alojamiento alojamiento = convertirDTOaEntidad(alojamientoDTO);
        Alojamiento nuevaHabitacion = alojamientoRepository.save(alojamiento);
    }


    public Map<String, Object> compararAlojamientos(int idAlojamiento1, int idAlojamiento2) {
        return alojamientoGateway.compararAlojamientos(idAlojamiento1, idAlojamiento2);
    }

    public List<AlojamientoDTO> buscarAlojamientos(PreferenciaEstudianteDTO preferencias) {
        return alojamientoGateway.buscarAlojamientos(preferencias);
    }

    private Alojamiento convertirDTOaEntidad(AlojamientoDTO alojamientoDTO) {
        Alojamiento alojamiento = new Alojamiento();
        alojamiento.setIdAlojamiento(alojamientoDTO.getIdAlojamiento());
        alojamiento.setNombreAlojamiento(alojamientoDTO.getNombreAlojamiento());
        alojamiento.setDescripcion(alojamientoDTO.getDescripcion());
        alojamiento.setDireccion(alojamientoDTO.getDireccion());
        alojamiento.setCiudad(alojamientoDTO.getCiudad());
        alojamiento.setPrecio(alojamientoDTO.getPrecio());
        alojamiento.setTieneLavanderia(alojamientoDTO.isTieneLavanderia());
        alojamiento.setTieneRoomie(alojamientoDTO.isTieneRoomie());
        alojamiento.setTieneParqueaderoBicicleta(alojamientoDTO.isTieneParqueaderoBicicleta());
        return alojamiento;
    }

}
