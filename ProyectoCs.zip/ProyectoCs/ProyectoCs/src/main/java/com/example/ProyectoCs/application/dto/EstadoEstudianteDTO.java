package com.example.ProyectoCs.application.dto;

import lombok.Data;

@Data
public class EstadoEstudianteDTO {
    private int idEstadoEstudiante;
    private String estadoEstudiante;
}
