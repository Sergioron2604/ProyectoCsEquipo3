package com.example.ProyectoCs.application.dto;

import lombok.Data;

@Data
public class EstadoReservaDTO {
    private int idEstadoReserva;
    private String estadoReserva;
}
