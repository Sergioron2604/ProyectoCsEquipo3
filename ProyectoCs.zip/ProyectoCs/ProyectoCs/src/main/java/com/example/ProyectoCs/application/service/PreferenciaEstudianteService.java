package com.example.ProyectoCs.application.service;

import com.example.ProyectoCs.application.dto.EstudianteDTO;
import com.example.ProyectoCs.application.dto.PreferenciaEstudianteDTO;
import com.example.ProyectoCs.domain.model.Estudiante;
import com.example.ProyectoCs.domain.model.PreferenciaEstudiante;
import com.example.ProyectoCs.domain.repository.EstudianteRepository;
import com.example.ProyectoCs.domain.repository.PreferenciaEstudianteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class PreferenciaEstudianteService {

    private final PreferenciaEstudianteRepository preferenciaEstudianteRepository;
    private final EstudianteRepository estudianteRepository;

    @Autowired
    public PreferenciaEstudianteService(PreferenciaEstudianteRepository preferenciaEstudianteRepository, EstudianteRepository estudianteRepository) {
        this.preferenciaEstudianteRepository = preferenciaEstudianteRepository;
        this.estudianteRepository = estudianteRepository;
    }

    public void saveEstudianteConPreferencia(EstudianteDTO estudianteDTO, PreferenciaEstudianteDTO preferenciaEstudianteDTO) {
        validateEstudiante(estudianteDTO);
        validate(preferenciaEstudianteDTO);

        Estudiante estudiante = convertEstudianteToEntity(estudianteDTO);
        estudianteRepository.save(estudiante);

        PreferenciaEstudiante preferenciaEstudiante = convertPreferenciaEstudianteToEntity(preferenciaEstudianteDTO);
        preferenciaEstudianteRepository.save(preferenciaEstudiante);
    }

    public void savePreferenciaEstudiante(PreferenciaEstudianteDTO preferenciaEstudianteDTO) {
        PreferenciaEstudiante preferenciaEstudiante = convertPreferenciaEstudianteToEntity(preferenciaEstudianteDTO);
        preferenciaEstudianteRepository.save(preferenciaEstudiante);
    }

    private Estudiante convertEstudianteToEntity(EstudianteDTO estudianteDTO) {
        Estudiante estudiante = new Estudiante();
        estudiante.setNombre(estudianteDTO.getNombre());
        estudiante.setEdad(estudianteDTO.getEdad());
        estudiante.setEmail(estudianteDTO.getEmail());
        estudiante.setTelefono(estudianteDTO.getTelefono());
        return estudiante;
    }

    private PreferenciaEstudiante convertPreferenciaEstudianteToEntity(PreferenciaEstudianteDTO preferenciaEstudianteDTO) {
        PreferenciaEstudiante preferenciaEstudiante = new PreferenciaEstudiante();
        preferenciaEstudiante.setIdPreferencia(preferenciaEstudianteDTO.getIdPreferencia());
        preferenciaEstudiante.setPresupuestoMaximo(preferenciaEstudianteDTO.getPresupuestoMaximo());
        preferenciaEstudiante.setDeseaLavanderia(preferenciaEstudianteDTO.isDeseaLavanderia());
        preferenciaEstudiante.setDeseaRoomie(preferenciaEstudianteDTO.isDeseaRoomie());
        preferenciaEstudiante.setNecesitaParqueaderoBicicleta(preferenciaEstudianteDTO.isNecesitaParqueaderoBicicleta());
        return preferenciaEstudiante;
    }


    private void validateEstudiante(EstudianteDTO dto) {
        if (dto.getIdEstudiante() == null) {
            throw new IllegalArgumentException("idEstudiante no puede ser nulo");
        }
        if (dto.getNombre() == null || dto.getNombre().isEmpty()) {
            throw new IllegalArgumentException("Nombre no puede estar vacío");
        }
        if (dto.getEdad() <= 0) {
            throw new IllegalArgumentException("Edad debe ser mayor que 0");
        }
        if (dto.getEmail() == null || dto.getEmail().isEmpty()) {
            throw new IllegalArgumentException("Email no puede estar vacío");
        }
        if (dto.getTelefono() == null || dto.getTelefono().isEmpty()) {
            throw new IllegalArgumentException("Teléfono no puede estar vacío");
        }
        if (dto.getIdUniversidad() <= 0) {
            throw new IllegalArgumentException("idUniversidad debe ser mayor que 0");
        }
        if (dto.getIdEstadoEstudiante() <= 0) {
            throw new IllegalArgumentException("idEstadoEstudiante debe ser mayor que 0");
        }
    }

    private void validate(PreferenciaEstudianteDTO dto) {
        if (dto.getIdPreferencia() <= 0) {
            throw new IllegalArgumentException("idPreferencia debe ser mayor que 0");
        }
        if (dto.getIdEstudiante() <= 0) {
            throw new IllegalArgumentException("idEstudiante debe ser mayor que 0");
        }
        if (dto.getPresupuestoMaximo() <= 0) {
            throw new IllegalArgumentException("presupuestoMaximo debe ser mayor que 0");
        }



    }
}