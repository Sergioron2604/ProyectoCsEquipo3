package com.example.ProyectoCs.infrastructure.gateway;

import com.example.ProyectoCs.application.dto.ComportamientoBusquedaDTO;

public interface ComportamientoBusquedaGateway {
    void saveComportamientoBusqueda(ComportamientoBusquedaDTO comportamientoBusquedaDTO);
}
