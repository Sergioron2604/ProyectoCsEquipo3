package com.example.ProyectoCs.application.dto;

import lombok.Data;

@Data
public class EstadoHabitacionDTO {
    private int idEstadoHabitacion;
    private String estadoHabitacion;


}
