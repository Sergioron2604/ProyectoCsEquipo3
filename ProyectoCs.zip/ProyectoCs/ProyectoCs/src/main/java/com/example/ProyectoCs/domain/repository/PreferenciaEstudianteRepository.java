package com.example.ProyectoCs.domain.repository;

import com.example.ProyectoCs.domain.model.PreferenciaEstudiante;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PreferenciaEstudianteRepository extends JpaRepository<PreferenciaEstudiante, Long> {
}
