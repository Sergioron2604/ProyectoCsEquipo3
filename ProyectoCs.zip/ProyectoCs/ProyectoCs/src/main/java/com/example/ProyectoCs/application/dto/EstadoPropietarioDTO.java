package com.example.ProyectoCs.application.dto;

import lombok.Data;

@Data
public class EstadoPropietarioDTO {
    private int idEstadoPropietario;
    private String estadoPropietario;
}
