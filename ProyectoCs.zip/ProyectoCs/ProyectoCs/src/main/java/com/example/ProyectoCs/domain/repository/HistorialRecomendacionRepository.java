package com.example.ProyectoCs.domain.repository;

import com.example.ProyectoCs.domain.model.HistorialRecomendacion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HistorialRecomendacionRepository extends JpaRepository<HistorialRecomendacion, Long> {
}
