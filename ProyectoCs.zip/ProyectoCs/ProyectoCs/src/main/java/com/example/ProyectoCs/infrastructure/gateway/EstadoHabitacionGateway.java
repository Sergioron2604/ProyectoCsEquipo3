package com.example.ProyectoCs.infrastructure.gateway;

import com.example.ProyectoCs.application.dto.EstadoHabitacionDTO;

public interface EstadoHabitacionGateway {
    void saveEstadoHabitacion(EstadoHabitacionDTO estadoHabitacionDTO);
}
