package com.example.ProyectoCs.application.dto;

import lombok.Data;

@Data
public class UniversidadDTO {
    private int idUniversidad;
    private String nombreUniversidad;
    private String direccion;
    private String ciudad;
}
