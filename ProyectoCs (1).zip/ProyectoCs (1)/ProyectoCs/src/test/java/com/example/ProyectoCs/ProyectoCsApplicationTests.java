package com.example.ProyectoCs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoCsApplicationTests {

	@Test
	void contextLoads() {
	}

}
