package com.example.ProyectoCs.infrastructure.SecurityCapa.Auth;

import com.example.ProyectoCs.application.dto.EstudianteDTO;

public class AuthDTO {
    public record LoginRequest(String username, String password) {
    }

    public record Response(String message, String token) {
    }
}