package com.example.ProyectoCs.infrastructure.SecurityCapa.Auth;

import com.example.ProyectoCs.application.dto.EstudianteDTO;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;

public class AuthEstudiante extends EstudianteDTO implements UserDetails {

    private final EstudianteDTO user;

    public AuthEstudiante(EstudianteDTO user) {
        this.user = user;
    }

    public EstudianteDTO getUser() {
        return user;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of();
    }

    @Override
    public String getPassword() {
        return user.getPassword(); // Suponiendo que EstudianteDTO tiene un campo de contraseña
    }

    @Override
    public String getUsername() {
        return user.getUsername(); // Suponiendo que EstudianteDTO tiene un campo de nombre de usuario
    }

    @Override
    public boolean isAccountNonExpired() {
        return false;
    }

    @Override
    public boolean isAccountNonLocked() {
        return false;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return false;
    }

    @Override
    public boolean isEnabled() {
        return false;
    }

    // Implementar otros métodos UserDetails según sea necesario
}
