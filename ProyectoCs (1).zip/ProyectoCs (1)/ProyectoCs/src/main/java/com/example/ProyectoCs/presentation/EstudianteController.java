package com.example.ProyectoCs.presentation;


import com.example.ProyectoCs.application.dto.EstudianteDTO;
import com.example.ProyectoCs.application.usescase.AlojamientoService;
import com.example.ProyectoCs.application.usescase.EstudianteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import java.util.Map;

@RestController
@RequestMapping("/api/estudiantes")
public class EstudianteController {

    private final EstudianteService estudianteService;
    private final AlojamientoService alojamientoService;

    @Autowired
    public EstudianteController(EstudianteService estudianteService, AlojamientoService alojamientoService) {
        this.estudianteService = estudianteService;
        this.alojamientoService = alojamientoService;
    }

    @PostMapping("/registrar")
    public ResponseEntity<String> registrarEstudiante(@RequestBody EstudianteDTO estudianteDTO) {
        try {
            estudianteService.registrarEstudiante(estudianteDTO);
            return ResponseEntity.ok("Estudiante registrado exitosamente");
        } catch (MessagingException | jakarta.mail.MessagingException e) {
            return ResponseEntity.status(500).body("Error al enviar notificación");
        } catch (IllegalStateException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("/eliminar")
    public ResponseEntity<String> eliminarEstudiante(@RequestParam String email) {
        try {
            estudianteService.eliminarEstudiante(email);
            return ResponseEntity.ok("Estudiante eliminado exitosamente");
        } catch (MessagingException | jakarta.mail.MessagingException e) {
            return ResponseEntity.status(500).body("Error al enviar notificación");
        } catch (IllegalStateException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/comparar-alojamientos")
    @PreAuthorize("hasRole('ESTUDIANTE')")
    public ResponseEntity<Map<String, Object>> compararAlojamientos(@RequestParam int idAlojamiento1, @RequestParam int idAlojamiento2) {
        try {
            Map<String, Object> comparacion = alojamientoService.compararAlojamientos(idAlojamiento1, idAlojamiento2);
            return ResponseEntity.ok(comparacion);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
}
