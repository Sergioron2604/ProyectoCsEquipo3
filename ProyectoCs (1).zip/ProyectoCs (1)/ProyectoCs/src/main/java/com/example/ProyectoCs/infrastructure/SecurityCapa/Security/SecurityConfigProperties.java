package com.example.ProyectoCs.infrastructure.SecurityCapa.Security;

public class SecurityConfigProperties {
}
