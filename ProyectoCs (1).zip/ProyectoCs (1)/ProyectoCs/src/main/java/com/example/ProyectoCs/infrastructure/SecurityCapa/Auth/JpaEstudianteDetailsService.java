package com.example.ProyectoCs.infrastructure.SecurityCapa.Auth;

import com.example.ProyectoCs.application.dto.EstudianteDTO;
import com.example.ProyectoCs.domain.repository.EstudianteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class JpaEstudianteDetailsService implements UserDetailsService {

    @Autowired
    private EstudianteRepository estudianteRepository;

    @Override
    public UserDetails loadUserByUsername(UUID username) throws UsernameNotFoundException {
        EstudianteDTO estudiante = estudianteRepository
                .findByIdEstudiante(username)
                .orElseThrow(() -> new UsernameNotFoundException("Estudiante no encontrado: " + username));

        return new AuthEstudiante(estudiante);
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        return null;
    }
}
